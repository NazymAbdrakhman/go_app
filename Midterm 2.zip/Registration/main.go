package main

import (
	"fmt"
	"html/template"
	"log"
	"net/http"
	"os"

	"github.com/NazymAbdrakhman/go_app/login"
)

func registrationHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method == "GET" {
		tmpl, err := template.ParseFiles("html/registration.html")
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		err = tmpl.Execute(w, nil)
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
	} else if r.Method == "POST" {
		// Get the form data from the request
		username := r.FormValue("username")
		password := r.FormValue("password")
		confirm := r.FormValue("confirm")

		// Check if passwords match
		if password != confirm {
			tmpl, err := template.ParseFiles("html/registration-error.html")
			if err != nil {
				http.Error(w, err.Error(), http.StatusInternalServerError)
				return
			}
			err = tmpl.Execute(w, "Passwords do not match")
			if err != nil {
				http.Error(w, err.Error(), http.StatusInternalServerError)
				return
			}
			return
		}

		// Open the users file in append mode
		file, err := os.OpenFile("users.txt", os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		defer file.Close()

		// Write the user's credentials to the users file
		userData := fmt.Sprintf("%s,%s\n", username, password)
		_, err = file.WriteString(userData)
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}

		// Redirect the user to the login page
		http.Redirect(w, r, "/authorize", http.StatusFound)
	}
}
func CategoriesHandler(w http.ResponseWriter, r *http.Request) {
	tmpl, err := template.ParseFiles("html/cat.html")
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	err = tmpl.Execute(w, nil)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
}
func BuybookHandler(w http.ResponseWriter, r *http.Request) {
	tmpl, err := template.ParseFiles("buy-book.html")
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	err = tmpl.Execute(w, nil)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
}

func main() {
	// http.HandleFunc("/cat", CategoriesHandler)
	http.HandleFunc("/register", registrationHandler)
	http.HandleFunc("/authorize", login.LoginHandler)
	http.HandleFunc("/cat", func(w http.ResponseWriter, r *http.Request) {
		renderHTML(w, "html/cat.html")
	})
	http.HandleFunc("/buy-book", func(w http.ResponseWriter, r *http.Request) {
		renderHTML(w, "buy-book.html")
	})
	// http.HandleFunc("/main-book", mainBookHandler)
	log.Println("Server is listening on port 0000...")
	err := http.ListenAndServe(":0000", nil)
	if err != nil {
		log.Fatal("ListenAndServe: ", err)
	}
}
